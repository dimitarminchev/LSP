int answer();
