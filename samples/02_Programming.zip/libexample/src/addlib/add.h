void setSummand(int summand);
int add(int summand);
