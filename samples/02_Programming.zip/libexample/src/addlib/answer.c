#include "add.h"
int answer() {
	setSummand(20);
	return add(22); // 42 = 20 + 22
}
