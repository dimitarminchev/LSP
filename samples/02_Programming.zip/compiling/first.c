#include<stdio.h>
int main()
{
	int a=20;
	int b=a+22;
	printf("%i\n",b);
	return 0;
}
